Substance Materials Documentation

Requires the substance plugin be installed. When that's done, open UE4, go to Edit > Plugins and enable the Substance plugin. 

Next make sure that the GPU Engine is enabled. This can be done by going to Edit -> Project Settings -> Scroll down to the bottom to Plugins/Substance -> Under 'Cooking', change the Substance Engine dropdown to GPU Engine.

Now restart UE4 and then you should be good to go.

===========================================================================
===========================================================================

-------------------------------------------------------------------
SUBSTANCE MATERIAL CONTROLS DOCUMENTATION.
-------------------------------------------------------------------

Substance material Controls can be found in the Textures Folder. They are the red colored files and each one effects the corresponding textures of the same name.

It is reccomended to drop the substance material down to a lower resolution for faster responce time to changes made with the controls. When you are satisfied bring the resolution back up to your desired output.

====================================================================
Dirt Path Generator
====================================================================

--------------------------------------------------------------------
Opacity
--------------------------------------------------------------------

Edge Opacity Slider: Shrinks the material from the edges in.

Edge Opacity Contrast: Contrast control for the Edge Opacity Slider.

---------------------------------------------------------------------
Switches
---------------------------------------------------------------------
AO On Off: Toggles ambient occlusion on the material.

Grass On Off: Toggles the grass.

Large Rocks On Off: Toggles the large rocks.

Small Rocks On Off: Toggles the small rocks.

Rut Gravel On Off: Toggles the gravel in the ruts.

1 Or 2 Ruts: Toggles 1 or 2 runs in the material.

Tire Tracks On Off: Toggles the tire tracks on the material.

FootPrints On Off: Toggels the footprints on the material.

Low Density or High Density Footprints: Toggles between 2 different sets of footprint tracks.

Water On Off: Toggels water on the material.

----------------------------------------------------------------------
Color
----------------------------------------------------------------------

Color pickers for grass, Dirt, Rock.

Controls for the spread and strength of highlights on the rocks.

----------------------------------------------------------------------
Grass
----------------------------------------------------------------------
Grass Slider: Controls the amount of grass on the material.

----------------------------------------------------------------------
Rock Dirt
----------------------------------------------------------------------
Dirt Level and Dirt Contrast: controls the spread of Dirt on the rocks.

----------------------------------------------------------------------
Ruts
----------------------------------------------------------------------

Rut Width: Controls the width of the ruts.

Rut Depth: Controls how deep the ruts cut into the ground on the material.

Rut Spacing: When 2 ruts are toggled on this controls the spacing between them.

Tire Tracks Strength: controls the intensity of the tire tracks showing up in the ruts.

Footprints Strength: Conrols the intensity of the foot prints showing up in the ruts.

-----------------------------------------------------------------------
Snow
-----------------------------------------------------------------------

Snow Slider and Snow Slider Contrast: Controls the spread of snow on the material.

-----------------------------------------------------------------------
Water
-----------------------------------------------------------------------
Water Level: sets the water level when water is turned on for the material.

Water Darkness: controls how dark the wet sections of the material are from the water.

Edges Wetness: controls how wet the edges around the puddles of water are.

Edges Wetness Distance: controls how far the wet endges spread out from the puddles.

Sludge color: color picker for the sludge that shows up in the puddles.

Sludge Depth: controls how far back the sludge is pushed away from the surface.

Sludge Opacity: Controls how much of the sludge shows up in the water.

Frost and Frost Intensity: sets the amount of ice showing up in the water.

Frost Cracks: Controls how much cracks show up in the ice.


  